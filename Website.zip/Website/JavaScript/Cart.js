let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

// Display cart items
function displayCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';

    if(cart.length === 0){
        cartItems.innerHTML = '<p>Your cart is empty.</p>';
        document.getElementById('total-price').innerText = '0';
        updateCartCount();
        return;
    }

    let total = 0;

    cart.forEach((item, index) => {
        total += item.price * item.quantity;

        const div = document.createElement('div');
        div.classList.add('cart-item');
        div.innerHTML = `
            <img src="${item.image}" alt="${item.name}" width="100">
            <div class="item-details">
                <p><strong>${item.name}</strong></p>
                <p>Color: ${item.color}</p>
                <p>Capacity: ${item.capacity}</p>
                <div class="quantity-box">
                    <button onclick="decreaseQty(${index})">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="increaseQty(${index})">+</button>
                </div>
                <p>RM ${item.price * item.quantity}</p>
                <button class="remove-btn" onclick="removeItem(${index})">Remove</button>
            </div>
            <hr>
        `;
        cartItems.appendChild(div);
    });

    document.getElementById('total-price').innerText = total.toFixed(2);
    updateCartCount();
}

// Quantity controls
function increaseQty(index) {
    if(cart[index].quantity < 5) {
        cart[index].quantity++;
        saveCart();
        displayCart();
    } else {
        alert("Maximum quantity is 5!");
    }
}

function decreaseQty(index) {
    if(cart[index].quantity > 1) {
        cart[index].quantity--;
        saveCart();
        displayCart();
    }
}

// Remove item from cart
function removeItem(index) {
    cart.splice(index, 1);
    saveCart();
    displayCart();
}

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Update cart count in navbar
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    if(cart.length > 0){
        countEl.style.display = 'flex';
        const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
        countEl.innerText = totalQty;
    } else {
        countEl.style.display = 'none';
    }
}

// Checkout with modal
function checkout() {
    if(cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Show checkout modal
    const modal = document.getElementById('checkoutModal');
    modal.style.display = 'block';

    // Clear cart
    cart = [];
    saveCart();
    displayCart();
    updateCartCount();
}

// Close modal
function closeModal() {
    const modal = document.getElementById('checkoutModal');
    modal.style.display = 'none';
}

// Initialize
window.onload = function() {
    displayCart();
    updateCartCount();
};
