// -------------------- VARIABLES --------------------
let selectedColor = 'orange';
let selectedModel = '';
let selectedCapacity = '';
let quantity = 1;
const maxQuantity = 5;

// Load cart from localStorage and ensure it's always an array
let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

// -------------------- IMAGE CHANGE --------------------
function changeImage(img) {
    document.getElementById('mainImage').src = img.src;
}

// -------------------- COLOR SELECTION --------------------
function selectColor(color) {
    selectedColor = color;
    document.getElementById('selectedColor').innerText =
        color.charAt(0).toUpperCase() + color.slice(1);

    // Highlight active color
    document.querySelectorAll('.color').forEach(c => c.classList.remove('active'));
    const activeColor = document.querySelector(`.color.${color}`);
    if (activeColor) activeColor.classList.add('active');

    // Update main image and thumbnails
    const colorName = color.charAt(0).toUpperCase() + color.slice(1);
    document.getElementById('mainImage').src = `Iphone/17P${colorName}1.png`;

    const thumbs = document.querySelectorAll('.thumbnail-row img');
    thumbs.forEach((t, i) => t.src = `Iphone/17P${colorName}${i + 1}.png`);
}

// -------------------- MODEL SELECTION --------------------
function selectModel(btn) {
    selectedModel = btn.innerText;
    document.querySelectorAll('#model-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- CAPACITY SELECTION --------------------
function selectCapacity(btn) {
    selectedCapacity = btn.innerText;
    document.querySelectorAll('#capacity-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- QUANTITY --------------------
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else {
        alert(`You can only purchase up to ${maxQuantity} units.`);
    }
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// -------------------- ADD TO CART --------------------
function addToCart() {
    // Validate selection
    if (!selectedColor || !selectedModel || !selectedCapacity) {
        alert("Please select all options before adding to cart!");
        return;
    }

    // Check if same item already exists
    const existingItem = cart.find(item =>
        item.name === selectedModel &&
        item.color === selectedColor &&
        item.capacity === selectedCapacity
    );

    if (existingItem) {
        // Increment quantity but do not exceed maxQuantity
        const newQty = existingItem.quantity + quantity;
        if (newQty > maxQuantity) {
            existingItem.quantity = maxQuantity;
            alert(`Maximum quantity for this product is ${maxQuantity}.`);
        } else {
            existingItem.quantity = newQty;
        }
    } else {
        // Add new item
        cart.push({
            name: selectedModel,
            color: selectedColor,
            capacity: selectedCapacity,
            quantity: quantity,
            price: 5999, // adjust as needed
            image: document.getElementById('mainImage').src
        });
    }

    // Save updated cart
    localStorage.setItem('cart', JSON.stringify(cart));

    // Update cart count badge
    updateCartCount();

    // Redirect to cart page
    setTimeout(() => {
        window.location.href = 'Cart.html';
    }, 100); // slight delay to ensure storage saves
}

// -------------------- CART COUNT --------------------
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);

    if(totalQty > 0){
        countEl.style.display = 'flex';
        countEl.innerText = totalQty;
    } else {
        countEl.style.display = 'none';
    }
}

// -------------------- INITIAL LOAD --------------------
window.onload = () => {
    updateCartCount();
    selectColor('orange'); // default color

    // Optional: select first model and capacity by default
    const defaultModelBtn = document.querySelector('#model-section .select-btn');
    if (defaultModelBtn) selectModel(defaultModelBtn);

    const defaultCapacityBtn = document.querySelector('#capacity-section .select-btn');
    if (defaultCapacityBtn) selectCapacity(defaultCapacityBtn);
};
