// ==================== VARIABLES ====================
let selectedColor = 'starlight';
let selectedModel = '';
let selectedCapacity = '';
let quantity = 1;
const maxQuantity = 5;

// Load cart safely
let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

// ==================== IMAGE CHANGE (THUMBNAILS) ====================
function changeImage(img) {
    document.getElementById('mainImage').src = img.src;
}

// ==================== COLOR SELECTION ====================
function selectColor(color) {
    selectedColor = color;

    // Map color for display text
    const displayNames = {
        starlight: "Starlight",
        silver: "Silver",
        blue: "Blue"
    };
    document.getElementById('selectedColor').innerText = displayNames[color];

    // Set active color button
    document.querySelectorAll('.color').forEach(c => c.classList.remove('active'));
    document.querySelector(`.color.${color}`)?.classList.add('active');

    // Map color for image filenames (exact)
    const imageMap = {
        starlight: "AirStarlight",
        silver: "AirSilver",
        blue: "AirBlue"
    };

    // Set main image
    document.getElementById('mainImage').src = `Mac/${imageMap[color]}1.png`;

    // Set thumbnails
    document.querySelectorAll('.thumbnail-row img').forEach((img, i) => {
        img.src = `Mac/${imageMap[color]}${i + 1}.png`;
    });
}

// ==================== MODEL SELECTION ====================
function selectModel(btn) {
    selectedModel = btn.innerText;

    document.querySelectorAll('#model-section .select-btn').forEach(b =>
        b.classList.remove('active')
    );
    btn.classList.add('active');
}

// ==================== CAPACITY SELECTION ====================
function selectCapacity(btn) {
    selectedCapacity = btn.innerText;

    document.querySelectorAll('#capacity-section .select-btn').forEach(b =>
        b.classList.remove('active')
    );
    btn.classList.add('active');
}

// ==================== QUANTITY ====================
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else {
        alert(`You can only purchase up to ${maxQuantity} units.`);
    }
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// ==================== ADD TO CART ====================
function addToCart() {
    if (!selectedColor || !selectedModel || !selectedCapacity) {
        alert("Please select color, processor, and capacity.");
        return;
    }

    // Check if the same product already exists in cart
    const existingItem = cart.find(item =>
        item.name === selectedModel &&
        item.color === selectedColor &&
        item.capacity === selectedCapacity
    );

    if (existingItem) {
        const newQty = existingItem.quantity + quantity;
        existingItem.quantity = newQty > maxQuantity ? maxQuantity : newQty;

        if (newQty > maxQuantity) {
            alert(`Maximum quantity allowed is ${maxQuantity}.`);
        }
    } else {
        cart.push({
            name: selectedModel,
            color: selectedColor,
            capacity: selectedCapacity,
            quantity: quantity,
            price: 5499,
            image: document.getElementById('mainImage').src
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();

    // Redirect to cart page
    window.location.href = "Cart.html";
}

// ==================== CART COUNT ====================
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);

    if (totalQty > 0) {
        countEl.style.display = 'flex';
        countEl.innerText = totalQty;
    } else {
        countEl.style.display = 'none';
    }
}

// ==================== INITIAL LOAD ====================
window.onload = () => {
    // Update cart badge
    updateCartCount();

    // Default color, model, and capacity
    selectColor('starlight');

    const defaultModel = document.querySelector('#model-section .select-btn');
    if (defaultModel) selectModel(defaultModel);

    const defaultCapacity = document.querySelector('#capacity-section .select-btn');
    if (defaultCapacity) selectCapacity(defaultCapacity);
};
