// ==================== VARIABLES ====================
let quantity = 1;
const maxQuantity = 5;

// Load cart safely
let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

// ==================== IMAGE CHANGE (THUMBNAILS) ====================
function changeImage(img) {
    document.getElementById('mainImage').src = img.src;
    document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
    img.classList.add('active');
}

// ==================== QUANTITY ====================
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else alert(`You can only purchase up to ${maxQuantity} units.`);
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// ==================== ADD TO CART ====================
function addToCart() {
    // Use product name as unique identifier
    const productName = "iPhone Air MagSafe Battery";
    const productPrice = 479;

    const existingItem = cart.find(item => item.name === productName);

    if (existingItem) {
        const newQty = existingItem.quantity + quantity;
        existingItem.quantity = newQty > maxQuantity ? maxQuantity : newQty;
        if (newQty > maxQuantity) alert(`Maximum quantity allowed is ${maxQuantity}.`);
    } else {
        cart.push({
            name: productName,
            quantity: quantity,
            price: productPrice,
            image: document.getElementById('mainImage').src
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    window.location.href = "Cart.html";
}

// ==================== CART COUNT ====================
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);

    if (totalQty > 0) {
        countEl.style.display = 'flex';
        countEl.innerText = totalQty;
    } else countEl.style.display = 'none';
}

// ==================== INITIAL LOAD ====================
window.onload = () => {
    updateCartCount();
    // Set first thumbnail as active by default
    const firstThumb = document.querySelector('.thumbnail-row img');
    if (firstThumb) firstThumb.classList.add('active');
};
