// ==================== VARIABLES ====================
let selectedModel = '';
let quantity = 1;
const maxQuantity = 5;

// Load cart safely
let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

// ==================== IMAGE CHANGE (THUMBNAILS) ====================
function changeImage(img) {
    document.getElementById('mainImage').src = img.src;
    document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
    img.classList.add('active');
}

function selectPack(btn) {
    selectedModel = btn.innerText;

    document.querySelectorAll('#pack-section .select-btn').forEach(b =>
        b.classList.remove('active')
    );
    btn.classList.add('active');
}

// ==================== QUANTITY ====================
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else alert(`You can only purchase up to ${maxQuantity} units.`);
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// ==================== ADD TO CART ====================
function addToCart() {
    if (!selectedModel) {
        alert("Please select a pack option.");
        return;
    }

    const existingItem = cart.find(item =>
        item.name === selectedModel
    );

    if (existingItem) {
        const newQty = existingItem.quantity + quantity;
        existingItem.quantity = newQty > maxQuantity ? maxQuantity : newQty;

        if (newQty > maxQuantity) alert(`Maximum quantity allowed is ${maxQuantity}.`);
    } else {
        cart.push({
            name: selectedModel,
            quantity: quantity,
            price: 129,
            image: document.getElementById('mainImage').src
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    window.location.href = "Cart.html";
}

// ==================== CART COUNT ====================
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);

    if (totalQty > 0) {
        countEl.style.display = 'flex';
        countEl.innerText = totalQty;
    } else countEl.style.display = 'none';
}

// ==================== INITIAL LOAD ====================
window.onload = () => {
    updateCartCount();

    const defaultModel = document.querySelector('#model-section .select-btn');
    if (defaultModel) selectModel(defaultModel);
};
