// -------------------- VARIABLES --------------------
let selectedColor = 'purple';
let selectedModel = '';
let selectedCapacity = '';
let quantity = 1;
const maxQuantity = 5;
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// -------------------- IMAGE CHANGE --------------------
function changeImage(img) {
    document.getElementById('mainImage').src = img.src;
}

// -------------------- COLOR SELECTION --------------------
function selectColor(color) {
    selectedColor = color;
    document.getElementById('selectedColor').innerText =
        color.charAt(0).toUpperCase() + color.slice(1);

    document.querySelectorAll('.color').forEach(c => c.classList.remove('active'));
    const activeColor = document.querySelector(`.color.${color}`);
    if (activeColor) activeColor.classList.add('active');

    const colorName = color.charAt(0).toUpperCase() + color.slice(1);

    // ✅ Folder path included
    document.getElementById('mainImage').src = `Ipad/IpadA${colorName}1.png`;

    const thumbs = document.querySelectorAll('.thumbnail-row img');
    thumbs.forEach((t, i) => t.src = `Ipad/IpadA${colorName}${i + 1}.png`);
}

// -------------------- MODEL SELECTION --------------------
function selectModel(btn) {
    selectedModel = btn.innerText;
    document.querySelectorAll('#model-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- CAPACITY SELECTION --------------------
function selectCapacity(btn) {
    selectedCapacity = btn.innerText;
    document.querySelectorAll('#capacity-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- QUANTITY --------------------
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else {
        alert(`Maximum quantity is ${maxQuantity}.`);
    }
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// -------------------- ADD TO CART --------------------
function addToCart() {
    if (!selectedColor || !selectedModel || !selectedCapacity) {
        alert("Please select all options!");
        return;
    }

    const existingItem = cart.find(item =>
        item.name === selectedModel &&
        item.color === selectedColor &&
        item.capacity === selectedCapacity
    );

    if (existingItem) {
        existingItem.quantity = Math.min(existingItem.quantity + quantity, maxQuantity);
    } else {
        cart.push({
            name: selectedModel,
            color: selectedColor,
            capacity: selectedCapacity,
            quantity: quantity,
            price: 2799,
            image: document.getElementById('mainImage').src
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    window.location.href = 'Cart.html';
}

// -------------------- CART COUNT --------------------
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
    countEl.style.display = totalQty > 0 ? 'flex' : 'none';
    countEl.innerText = totalQty;
}

// -------------------- INITIAL LOAD --------------------
window.onload = () => {
    updateCartCount();
    selectColor('purple');

    const defaultModelBtn = document.querySelector('#model-section .select-btn');
    if (defaultModelBtn) selectModel(defaultModelBtn);

    const defaultCapacityBtn = document.querySelector('#capacity-section .select-btn');
    if (defaultCapacityBtn) selectCapacity(defaultCapacityBtn);
};
