// -------------------- INITIAL VARIABLES --------------------
let selectedColor = 'blue'; // match default
let selectedModel = '';
let selectedCapacity = '';
let quantity = 1;
const maxQuantity = 5;

let cart = JSON.parse(localStorage.getItem('cart')) || [];

// -------------------- IMAGE CHANGE --------------------
function changeImage(img) {
    document.getElementById('mainImage').src = img.src;
}

// -------------------- COLOR SELECTION --------------------
function selectColor(color) {
    selectedColor = color;
    document.getElementById('selectedColor').innerText =
        color.charAt(0).toUpperCase() + color.slice(1);

    // Highlight active color
    document.querySelectorAll('.color').forEach(c => c.classList.remove('active'));
    const activeColor = document.querySelector(`.color.${color}`);
    if (activeColor) activeColor.classList.add('active');

    // Update main image and thumbnails for iPad
    const colorName = color.charAt(0).toUpperCase() + color.slice(1);
    document.getElementById('mainImage').src = `Ipad/Ipad${colorName}1.png`;

    const thumbs = document.querySelectorAll('.thumbnail-row img');
    thumbs.forEach((t, i) => t.src = `Ipad/Ipad${colorName}${i + 1}.png`);
}

// -------------------- MODEL SELECTION --------------------
function selectModel(btn) {
    selectedModel = btn.innerText;
    document.querySelectorAll('#model-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- CAPACITY SELECTION --------------------
function selectCapacity(btn) {
    selectedCapacity = btn.innerText;
    document.querySelectorAll('#capacity-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- QUANTITY --------------------
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else {
        alert(`You can only purchase up to ${maxQuantity} units.`);
    }
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// -------------------- ADD TO CART --------------------
function addToCart() {
    if (!selectedColor || !selectedModel || !selectedCapacity) {
        alert("Please select all options before adding to cart!");
        return;
    }

    const existingItem = cart.find(item =>
        item.name === selectedModel &&
        item.color === selectedColor &&
        item.capacity === selectedCapacity
    );

    if (existingItem) {
        const newQty = existingItem.quantity + quantity;
        existingItem.quantity = Math.min(newQty, maxQuantity);
        if (newQty > maxQuantity) alert(`Maximum quantity for this product is ${maxQuantity}.`);
    } else {
        cart.push({
            name: selectedModel,
            color: selectedColor,
            capacity: selectedCapacity,
            quantity: quantity,
            price: 1599, // match displayed price
            image: document.getElementById('mainImage').src
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();

    window.location.href = 'Cart.html';
}

// -------------------- CART COUNT --------------------
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);

    if(totalQty > 0){
        countEl.style.display = 'flex';
        countEl.innerText = totalQty;
    } else {
        countEl.style.display = 'none';
    }
}

// -------------------- INITIAL LOAD --------------------
window.onload = () => {
    updateCartCount();
    selectColor('blue'); // default color

    const defaultModelBtn = document.querySelector('#model-section .select-btn');
    if (defaultModelBtn) selectModel(defaultModelBtn);

    const defaultCapacityBtn = document.querySelector('#capacity-section .select-btn');
    if (defaultCapacityBtn) selectCapacity(defaultCapacityBtn);
};
