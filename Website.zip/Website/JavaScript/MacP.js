// -------------------- VARIABLES --------------------
let selectedColor = 'silver'; // default color
let selectedModel = '';
let selectedCapacity = '';
let quantity = 1;
const maxQuantity = 5;

// Define color mapping: prefix and number of images per color
const colorMap = {
    "silver": { prefix: "ProSilver", count: 3 },
    "black": { prefix: "ProBlack", count: 3 }
};

// Load cart from localStorage
let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

// -------------------- IMAGE & THUMBNAILS --------------------
function updateThumbnails(color) {
    const mainImage = document.getElementById('mainImage');
    const thumbnailRow = document.getElementById('thumbnailRow');
    const { prefix, count } = colorMap[color];

    // Clear thumbnails
    thumbnailRow.innerHTML = '';

    // Add images for this color
    for (let i = 1; i <= count; i++) {
        const thumb = document.createElement('img');
        thumb.src = `Mac/${prefix}${i}.png`;
        thumb.classList.add('thumb');
        if (i === 1) thumb.classList.add('active');
        thumb.addEventListener('click', () => {
            mainImage.src = thumb.src;
            document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
        });
        thumbnailRow.appendChild(thumb);
    }

    mainImage.src = `Mac/${prefix}1.png`;
}

// -------------------- COLOR SELECTION --------------------
function selectColor(color) {
    selectedColor = color;

    // Update text
    document.getElementById('selectedColor').innerText =
        color.charAt(0).toUpperCase() + color.slice(1);

    // Highlight active color
    document.querySelectorAll('.color').forEach(c => c.classList.remove('active'));
    const activeColor = Array.from(document.querySelectorAll('.color'))
        .find(c => c.getAttribute('onclick').includes(color));
    if (activeColor) activeColor.classList.add('active');

    // Update images
    updateThumbnails(color);
}

// -------------------- MODEL SELECTION --------------------
function selectModel(btn) {
    selectedModel = btn.innerText;
    document.querySelectorAll('#model-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- CAPACITY SELECTION --------------------
function selectCapacity(btn) {
    selectedCapacity = btn.innerText;
    document.querySelectorAll('#capacity-section .select-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// -------------------- QUANTITY --------------------
function increase() {
    if (quantity < maxQuantity) {
        quantity++;
        document.getElementById('qty').innerText = quantity;
    } else alert(`Maximum quantity is ${maxQuantity}.`);
}

function decrease() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('qty').innerText = quantity;
    }
}

// -------------------- ADD TO CART --------------------
function addToCart() {
    if (!selectedColor || !selectedModel || !selectedCapacity) {
        alert("Please select all options!");
        return;
    }

    const existingItem = cart.find(item =>
        item.name === selectedModel &&
        item.color === selectedColor &&
        item.capacity === selectedCapacity
    );

    if (existingItem) {
        existingItem.quantity = Math.min(existingItem.quantity + quantity, maxQuantity);
        if(existingItem.quantity === maxQuantity) alert(`Max ${maxQuantity} units allowed.`);
    } else {
        cart.push({
            name: selectedModel,
            color: selectedColor,
            capacity: selectedCapacity,
            quantity: quantity,
            price: 6999,
            image: document.getElementById('mainImage').src
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    setTimeout(() => window.location.href = 'Cart.html', 100);
}

// -------------------- CART COUNT --------------------
function updateCartCount() {
    const countEl = document.getElementById('cart-count');
    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
    if (totalQty > 0) {
        countEl.style.display = 'flex';
        countEl.innerText = totalQty;
    } else {
        countEl.style.display = 'none';
    }
}

// -------------------- INITIAL LOAD --------------------
window.onload = () => {
    updateCartCount();

    // Default selections
    const defaultModelBtn = document.querySelector('#model-section .select-btn');
    if(defaultModelBtn) selectModel(defaultModelBtn);

    const defaultCapacityBtn = document.querySelector('#capacity-section .select-btn');
    if(defaultCapacityBtn) selectCapacity(defaultCapacityBtn);

    selectColor(selectedColor);
};
