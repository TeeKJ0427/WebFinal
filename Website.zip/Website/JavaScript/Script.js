window.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
});

/* =======================
   Slideshow
======================= */
const images = [
    "SlideShow/Slide1.png",
    "SlideShow/Slide2.png",
    "SlideShow/Slide3.png"
];

let index = 0;
const slideImage = document.getElementById("slideImage");

if (slideImage) {
    setInterval(() => {
        index = (index + 1) % images.length;
        slideImage.src = images[index];
    }, 3000);
}

/* =======================
   Product Color Change
======================= */
const products = document.querySelectorAll('.product, .product-card');

products.forEach(product => {
    const img = product.querySelector('img');
    const colors = product.querySelectorAll('.color-circle');

    colors.forEach(color => {
        color.addEventListener('click', () => {
            const newSrc = color.getAttribute('data-img');
            if (img && newSrc) img.src = newSrc;
        });
    });
});

/* =======================
   Signup Validation + Live Format + Modal
======================= */
const signupForm = document.getElementById('signupForm');
const phoneInput = document.getElementById('phone');
const phoneError = document.getElementById('phone-error');

if (phoneInput) {
    // Auto-format phone number as user types
    phoneInput.addEventListener('input', () => {
        let digits = phoneInput.value.replace(/\D/g, ''); // only digits

        if (digits.startsWith('60')) digits = digits.slice(2); // remove leading 60
        digits = digits.slice(0, 10); // max 10 digits after +60

        let formatted = '+60';
        if (digits.length > 0) formatted += digits.slice(0, 2);
        if (digits.length > 2) formatted += '-' + digits.slice(2, 5);
        if (digits.length > 5) formatted += ' ' + digits.slice(5, 9);

        phoneInput.value = formatted;
    });
}

if (signupForm) {
    const successModal = document.getElementById('successModal');
    const successMessage = document.getElementById('successMessage');
    const closeModal = document.getElementById('closeModal');

    signupForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const name = document.getElementById('name').value.trim();
        const phone = phoneInput.value.trim();

        const phoneRegex = /^\+60\d{2}-\d{3}\s\d{4}$/;
        const digitsOnly = phone.replace(/\D/g, '');

        if (!phoneRegex.test(phone) || digitsOnly.length < 11 || digitsOnly.length > 12) {
            if (phoneError) {
                phoneError.textContent = 'Invalid format. Please use +6012-345 6789.';
                phoneError.style.display = 'block';
            }
            phoneInput.classList.add('invalid');
            return;
        }

        if (phoneError) phoneError.style.display = 'none';
        phoneInput.classList.remove('invalid');

        // Show custom modal instead of alert
        successMessage.textContent = `You have successfully signed up with phone number ${phone}.`;
        successModal.style.display = 'block';
        signupForm.reset();

        // Close modal when clicking X
        closeModal.onclick = () => successModal.style.display = 'none';

        // Close modal when clicking outside modal
        window.onclick = (event) => {
            if (event.target == successModal) successModal.style.display = 'none';
        };
    });
}

/* =======================
   Cart Logic
======================= */
let cart = JSON.parse(localStorage.getItem('cart'));
cart = Array.isArray(cart) ? cart : [];

function updateCartCount() {
    const countEl = document.getElementById('cart-count');

    if (countEl) {
        if (cart.length > 0) {
            countEl.style.display = 'flex';
            const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
            countEl.innerText = totalQty;
        } else {
            countEl.style.display = 'none';
        }
    }
}
